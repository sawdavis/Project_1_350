--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.13 (Ubuntu 14.13-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE project_1;
--
-- Name: project_1; Type: DATABASE; Schema: -; Owner: abc
--

CREATE DATABASE project_1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE project_1 OWNER TO abc;

\connect project_1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calculate_tariff(character varying, character varying); Type: FUNCTION; Schema: public; Owner: abc
--

CREATE FUNCTION public.calculate_tariff(commodity_name character varying, country_iso_code character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    tariff_rate NUMERIC;
BEGIN
    SELECT tariff_rate INTO tariff_rate
    FROM tariffs
    JOIN commodities ON tariffs.commodity_id = commodities.commodity_id
    JOIN countries ON tariffs.country_id = countries.country_id
    WHERE commodities.commodity_name = commodity_name AND countries.iso_code = country_iso_code;
    
    RETURN COALESCE(tariff_rate, 0);
END;
$$;


ALTER FUNCTION public.calculate_tariff(commodity_name character varying, country_iso_code character varying) OWNER TO abc;

--
-- Name: total_trade_value(character varying, character varying); Type: FUNCTION; Schema: public; Owner: abc
--

CREATE FUNCTION public.total_trade_value(country_iso_code character varying, trade_type character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_value NUMERIC;
BEGIN
    SELECT SUM(value) INTO total_value
    FROM import_export_transactions
    JOIN countries ON import_export_transactions.country_id = countries.country_id
    WHERE countries.iso_code = country_iso_code AND trade_type = trade_type;
    
    RETURN COALESCE(total_value, 0);
END;
$$;


ALTER FUNCTION public.total_trade_value(country_iso_code character varying, trade_type character varying) OWNER TO abc;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commodities; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.commodities (
    commodity_id integer NOT NULL,
    commodity_name character varying(255) NOT NULL,
    hs_code character varying(10) NOT NULL,
    description text
);


ALTER TABLE public.commodities OWNER TO abc;

--
-- Name: commodities_commodity_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.commodities_commodity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commodities_commodity_id_seq OWNER TO abc;

--
-- Name: commodities_commodity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.commodities_commodity_id_seq OWNED BY public.commodities.commodity_id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.countries (
    country_id integer NOT NULL,
    country_name character varying(100) NOT NULL,
    iso_code character(3) NOT NULL
);


ALTER TABLE public.countries OWNER TO abc;

--
-- Name: countries_country_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.countries_country_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.countries_country_id_seq OWNER TO abc;

--
-- Name: countries_country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.countries_country_id_seq OWNED BY public.countries.country_id;


--
-- Name: customs_procedures; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.customs_procedures (
    procedure_id integer NOT NULL,
    transaction_id integer,
    procedure_description text NOT NULL,
    procedure_date date NOT NULL
);


ALTER TABLE public.customs_procedures OWNER TO abc;

--
-- Name: customs_procedures_procedure_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.customs_procedures_procedure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customs_procedures_procedure_id_seq OWNER TO abc;

--
-- Name: customs_procedures_procedure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.customs_procedures_procedure_id_seq OWNED BY public.customs_procedures.procedure_id;


--
-- Name: import_export_transactions; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.import_export_transactions (
    transaction_id integer NOT NULL,
    trade_type character varying(10) NOT NULL,
    commodity_id integer,
    country_id integer,
    port_id integer,
    transportation_id integer,
    value numeric(15,2) NOT NULL,
    transaction_date date NOT NULL
);


ALTER TABLE public.import_export_transactions OWNER TO abc;

--
-- Name: import_export_transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.import_export_transactions_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.import_export_transactions_transaction_id_seq OWNER TO abc;

--
-- Name: import_export_transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.import_export_transactions_transaction_id_seq OWNED BY public.import_export_transactions.transaction_id;


--
-- Name: ports; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.ports (
    port_id integer NOT NULL,
    port_name character varying(255) NOT NULL,
    country_id integer,
    port_type character varying(20)
);


ALTER TABLE public.ports OWNER TO abc;

--
-- Name: ports_port_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.ports_port_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ports_port_id_seq OWNER TO abc;

--
-- Name: ports_port_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.ports_port_id_seq OWNED BY public.ports.port_id;


--
-- Name: regulatory_agencies; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.regulatory_agencies (
    agency_id integer NOT NULL,
    agency_name character varying(255) NOT NULL,
    agency_code character(4) NOT NULL
);


ALTER TABLE public.regulatory_agencies OWNER TO abc;

--
-- Name: regulatory_agencies_agency_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.regulatory_agencies_agency_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.regulatory_agencies_agency_id_seq OWNER TO abc;

--
-- Name: regulatory_agencies_agency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.regulatory_agencies_agency_id_seq OWNED BY public.regulatory_agencies.agency_id;


--
-- Name: tariffs; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.tariffs (
    tariff_id integer NOT NULL,
    commodity_id integer,
    country_id integer,
    tariff_rate numeric(5,2) NOT NULL
);


ALTER TABLE public.tariffs OWNER TO abc;

--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.tariffs_tariff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tariffs_tariff_id_seq OWNER TO abc;

--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.tariffs_tariff_id_seq OWNED BY public.tariffs.tariff_id;


--
-- Name: transaction_agencies; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.transaction_agencies (
    transaction_id integer NOT NULL,
    agency_id integer NOT NULL
);


ALTER TABLE public.transaction_agencies OWNER TO abc;

--
-- Name: transportation_methods; Type: TABLE; Schema: public; Owner: abc
--

CREATE TABLE public.transportation_methods (
    method_id integer NOT NULL,
    method_name character varying(50) NOT NULL
);


ALTER TABLE public.transportation_methods OWNER TO abc;

--
-- Name: transportation_methods_method_id_seq; Type: SEQUENCE; Schema: public; Owner: abc
--

CREATE SEQUENCE public.transportation_methods_method_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transportation_methods_method_id_seq OWNER TO abc;

--
-- Name: transportation_methods_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: abc
--

ALTER SEQUENCE public.transportation_methods_method_id_seq OWNED BY public.transportation_methods.method_id;


--
-- Name: commodities commodity_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.commodities ALTER COLUMN commodity_id SET DEFAULT nextval('public.commodities_commodity_id_seq'::regclass);


--
-- Name: countries country_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.countries ALTER COLUMN country_id SET DEFAULT nextval('public.countries_country_id_seq'::regclass);


--
-- Name: customs_procedures procedure_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.customs_procedures ALTER COLUMN procedure_id SET DEFAULT nextval('public.customs_procedures_procedure_id_seq'::regclass);


--
-- Name: import_export_transactions transaction_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.import_export_transactions_transaction_id_seq'::regclass);


--
-- Name: ports port_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.ports ALTER COLUMN port_id SET DEFAULT nextval('public.ports_port_id_seq'::regclass);


--
-- Name: regulatory_agencies agency_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.regulatory_agencies ALTER COLUMN agency_id SET DEFAULT nextval('public.regulatory_agencies_agency_id_seq'::regclass);


--
-- Name: tariffs tariff_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.tariffs ALTER COLUMN tariff_id SET DEFAULT nextval('public.tariffs_tariff_id_seq'::regclass);


--
-- Name: transportation_methods method_id; Type: DEFAULT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.transportation_methods ALTER COLUMN method_id SET DEFAULT nextval('public.transportation_methods_method_id_seq'::regclass);


--
-- Data for Name: commodities; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.commodities (commodity_id, commodity_name, hs_code, description) FROM stdin;
\.
COPY public.commodities (commodity_id, commodity_name, hs_code, description) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.countries (country_id, country_name, iso_code) FROM stdin;
\.
COPY public.countries (country_id, country_name, iso_code) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: customs_procedures; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.customs_procedures (procedure_id, transaction_id, procedure_description, procedure_date) FROM stdin;
\.
COPY public.customs_procedures (procedure_id, transaction_id, procedure_description, procedure_date) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: import_export_transactions; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.import_export_transactions (transaction_id, trade_type, commodity_id, country_id, port_id, transportation_id, value, transaction_date) FROM stdin;
\.
COPY public.import_export_transactions (transaction_id, trade_type, commodity_id, country_id, port_id, transportation_id, value, transaction_date) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: ports; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.ports (port_id, port_name, country_id, port_type) FROM stdin;
\.
COPY public.ports (port_id, port_name, country_id, port_type) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: regulatory_agencies; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.regulatory_agencies (agency_id, agency_name, agency_code) FROM stdin;
\.
COPY public.regulatory_agencies (agency_id, agency_name, agency_code) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: tariffs; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.tariffs (tariff_id, commodity_id, country_id, tariff_rate) FROM stdin;
\.
COPY public.tariffs (tariff_id, commodity_id, country_id, tariff_rate) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: transaction_agencies; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.transaction_agencies (transaction_id, agency_id) FROM stdin;
\.
COPY public.transaction_agencies (transaction_id, agency_id) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: transportation_methods; Type: TABLE DATA; Schema: public; Owner: abc
--

COPY public.transportation_methods (method_id, method_name) FROM stdin;
\.
COPY public.transportation_methods (method_id, method_name) FROM '$$PATH$$/3392.dat';

--
-- Name: commodities_commodity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.commodities_commodity_id_seq', 10, true);


--
-- Name: countries_country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.countries_country_id_seq', 12, true);


--
-- Name: customs_procedures_procedure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.customs_procedures_procedure_id_seq', 1, false);


--
-- Name: import_export_transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.import_export_transactions_transaction_id_seq', 6, true);


--
-- Name: ports_port_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.ports_port_id_seq', 8, true);


--
-- Name: regulatory_agencies_agency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.regulatory_agencies_agency_id_seq', 8, true);


--
-- Name: tariffs_tariff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.tariffs_tariff_id_seq', 6, true);


--
-- Name: transportation_methods_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: abc
--

SELECT pg_catalog.setval('public.transportation_methods_method_id_seq', 5, true);


--
-- Name: commodities commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.commodities
    ADD CONSTRAINT commodities_pkey PRIMARY KEY (commodity_id);


--
-- Name: countries countries_iso_code_key; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_iso_code_key UNIQUE (iso_code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (country_id);


--
-- Name: customs_procedures customs_procedures_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.customs_procedures
    ADD CONSTRAINT customs_procedures_pkey PRIMARY KEY (procedure_id);


--
-- Name: import_export_transactions import_export_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions
    ADD CONSTRAINT import_export_transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: ports ports_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.ports
    ADD CONSTRAINT ports_pkey PRIMARY KEY (port_id);


--
-- Name: regulatory_agencies regulatory_agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.regulatory_agencies
    ADD CONSTRAINT regulatory_agencies_pkey PRIMARY KEY (agency_id);


--
-- Name: tariffs tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_pkey PRIMARY KEY (tariff_id);


--
-- Name: transaction_agencies transaction_agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.transaction_agencies
    ADD CONSTRAINT transaction_agencies_pkey PRIMARY KEY (transaction_id, agency_id);


--
-- Name: transportation_methods transportation_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.transportation_methods
    ADD CONSTRAINT transportation_methods_pkey PRIMARY KEY (method_id);


--
-- Name: customs_procedures customs_procedures_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.customs_procedures
    ADD CONSTRAINT customs_procedures_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.import_export_transactions(transaction_id);


--
-- Name: import_export_transactions import_export_transactions_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions
    ADD CONSTRAINT import_export_transactions_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(commodity_id);


--
-- Name: import_export_transactions import_export_transactions_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions
    ADD CONSTRAINT import_export_transactions_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(country_id);


--
-- Name: import_export_transactions import_export_transactions_port_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions
    ADD CONSTRAINT import_export_transactions_port_id_fkey FOREIGN KEY (port_id) REFERENCES public.ports(port_id);


--
-- Name: import_export_transactions import_export_transactions_transportation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.import_export_transactions
    ADD CONSTRAINT import_export_transactions_transportation_id_fkey FOREIGN KEY (transportation_id) REFERENCES public.transportation_methods(method_id);


--
-- Name: ports ports_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.ports
    ADD CONSTRAINT ports_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(country_id);


--
-- Name: tariffs tariffs_commodity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_commodity_id_fkey FOREIGN KEY (commodity_id) REFERENCES public.commodities(commodity_id);


--
-- Name: tariffs tariffs_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.tariffs
    ADD CONSTRAINT tariffs_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.countries(country_id);


--
-- Name: transaction_agencies transaction_agencies_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.transaction_agencies
    ADD CONSTRAINT transaction_agencies_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.regulatory_agencies(agency_id);


--
-- Name: transaction_agencies transaction_agencies_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: abc
--

ALTER TABLE ONLY public.transaction_agencies
    ADD CONSTRAINT transaction_agencies_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.import_export_transactions(transaction_id);


--
-- PostgreSQL database dump complete
--

